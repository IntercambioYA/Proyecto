<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['id_usuario'])) {
  header("Location: index.php");
  exit;
}

$id_usuario = $_SESSION['id_usuario'];
$id_producto_destino = (int)($_POST['id_producto_destino'] ?? 0);

$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) die("DB error: " . $mysqli->connect_error);


$stmt = $mysqli->prepare("SELECT nombre, foto FROM Producto WHERE id_producto = ?");
$stmt->bind_param("i", $id_producto_destino);
$stmt->execute();
$producto_destino = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$producto_destino) {
  echo "<script>alert('Producto no encontrado.');window.location='intercambio.php';</script>";
  exit;
}


$stmt = $mysqli->prepare("SELECT id_producto, nombre, estado, foto FROM Producto WHERE id_usuario = ? AND estado = 'Disponible'");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$productos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


if (!isset($_SESSION['pagina_origen'])) {
    $_SESSION['pagina_origen'] = $_SERVER['HTTP_REFERER'] ?? 'intercambio.php';
}
if (basename($_SERVER['PHP_SELF']) === 'index.php' || basename($_SERVER['PHP_SELF']) === 'intercambio.php') {
    $_SESSION['pagina_origen'] = $_SERVER['PHP_SELF'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Seleccionar producto - IntercambioYA</title>
  <link rel="stylesheet" href="css/seleccionar_producto.css" />
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo" />
    <a href="<?= htmlspecialchars($_SESSION['pagina_origen'] ?? 'intercambio.php') ?>" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <a href="mis_trueques.php">Mis Intercambios</a>
    <a href="chats.php" class="active">Chats</a>
    <a href="perfil.php">Mi perfil</a>
    <form action="php/controller.php" method="POST" class="logout-form">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Cerrar sesión</button>
    </form>
  </nav>
</header>

<main class="trueques-container">
  <h2>Ofrecer trueque por: <span><?= htmlspecialchars($producto_destino['nombre']) ?></span></h2>

  <?php if (!empty($producto_destino['foto'])): ?>
    <div style="text-align:center;margin-bottom:1.5rem;">
      <img src="<?= htmlspecialchars($producto_destino['foto']) ?>" alt="<?= htmlspecialchars($producto_destino['nombre']) ?>" style="max-width:180px;border-radius:10px;">
    </div>
  <?php endif; ?>

  <?php if (empty($productos)): ?>
    <p class="vacio">No tenés productos disponibles para ofrecer.</p>
  <?php else: ?>
    <h3>Seleccioná uno de tus productos</h3>
    <div class="lista-trueques">
      <?php foreach ($productos as $p): ?>
        <div class="trueque-card">
          <img src="<?= htmlspecialchars($p['foto'] ?: 'img/default-product.png') ?>" alt="<?= htmlspecialchars($p['nombre']) ?>">
          <h3><?= htmlspecialchars($p['nombre']) ?></h3>
          <p><strong>Estado:</strong> <?= htmlspecialchars($p['estado']) ?></p>

          <form action="php/trueque.php" method="POST">
            <input type="hidden" name="action" value="ofrecer_trueque">
            <input type="hidden" name="id_producto_ofrecido" value="<?= (int)$p['id_producto'] ?>">
            <input type="hidden" name="id_producto_objetivo" value="<?= (int)$id_producto_destino ?>">
            <button type="submit" class="btn-trueque">Intercambiar</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

</body>
</html>
