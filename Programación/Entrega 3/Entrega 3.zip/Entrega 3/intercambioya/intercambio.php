<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuario = $_SESSION['primer_nombre'] ?? null;
$rol = $_SESSION['rol'] ?? null;

// Guardar la primera página visitada (si no existe ya)
if (!isset($_SESSION['pagina_origen'])) {
    $_SESSION['pagina_origen'] = $_SERVER['HTTP_REFERER'] ?? 'intercambio.php';
}

// Si está en el index o intercambio, reinicia el origen
if (basename($_SERVER['PHP_SELF']) === 'index.php' || basename($_SERVER['PHP_SELF']) === 'intercambio.php') {
    $_SESSION['pagina_origen'] = $_SERVER['PHP_SELF'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IntercambioYA - Intercambios</title>
  <link rel="stylesheet" href="css/intercambio.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>


<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo">

    
    <div class="dropdown">
      <button class="dropbtn">Categorías</button>
      <div class="dropdown-content" id="categorias"></div>
    </div>
  </div>

  <nav class="nav-links">
    <?php if (isset($_SESSION['id_usuario'])): ?>

      <?php if (strcasecmp($rol, 'Administrador') === 0): ?>
        
        <a href="admin_panel.php">Panel de administración</a>
        <a href="intercambio.php">Productos</a>
        <a href="chats.php">Vigilar Chats</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>

      <?php else: ?>
        
        <a href="index.php">Inicio</a>
        <a href="subir.php">Subir producto</a>
        <a href="mis_trueques.php">Mis Intercambios</a>
        <a href="chats.php" class="active">Chats</a>
        <a href="perfil.php">Mi perfil</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php endif; ?>

    <?php else: ?>
      
      <a href="index.php">Inicio</a>
      <a href="#" onclick="abrirModal('modalRegistro')">Registro</a>
      <a href="#" onclick="abrirModal('modalLogin')">Iniciar sesión</a>
    <?php endif; ?>
  </nav>
</header>



<section class="galeria">
  <h1>Objetos para Intercambiar</h1>
  <div id="productosContainer" class="productos-grid"></div>
</section>


<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>


<div id="modalLogin" class="modal">
  <div class="modal-content">
    <span class="close" onclick="cerrarModal('modalLogin')">&times;</span>
    <h2>Iniciar Sesión</h2>
    <form action="php/controller.php" method="POST">
      <input type="hidden" name="action" value="login">
      <input type="email" name="email" placeholder="Correo electrónico" required autocomplete="off">
      <input type="password" name="clave" placeholder="Contraseña" required autocomplete="off">
      <button type="submit" class="btn-intercambio">Ingresar</button>
    </form>
  </div>
</div>

<div id="modalRegistro" class="modal">
  <div class="modal-content">
    <span class="close" onclick="cerrarModal('modalRegistro')">&times;</span>
    <h2>Registro</h2>
    <form action="php/controller.php" method="POST">
      <input type="hidden" name="action" value="register">
      <input type="text" name="primer_nombre" placeholder="Nombre" required autocomplete="off">
      <input type="text" name="primer_apellido" placeholder="Apellido" required autocomplete="off">
      <input type="email" name="email" placeholder="Correo electrónico" required autocomplete="off">
      <input type="tel" name="telefono" placeholder="Teléfono" autocomplete="off">
      <input type="password" name="clave" placeholder="Contraseña" required autocomplete="off">
      <button type="submit" class="btn-intercambio">Registrarse</button>
    </form>
  </div>
</div>


<script>
function abrirModal(id){document.getElementById(id).style.display='block';}
function cerrarModal(id){document.getElementById(id).style.display='none';}
window.addEventListener('click', (e)=>{
  ['modalLogin','modalRegistro'].forEach(id=>{
    const m=document.getElementById(id);
    if(e.target===m)m.style.display='none';
  });
});


async function fetchJSON(url) {
  const res = await fetch(url, { cache: 'no-store' });
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    console.error('Respuesta no JSON:', text);
    throw new Error('Respuesta inválida del servidor.');
  }
}


document.addEventListener('DOMContentLoaded', async () => {
  console.log("Cargando categorías...");
  const cont = document.getElementById('categorias');
  const productosContainer = document.getElementById('productosContainer');

  try {
    const categorias = await fetchJSON('php/controller.php?get=categorias');
    console.log("Categorías recibidas:", categorias);

    const lista = ['Todas', ...categorias];
    cont.innerHTML = lista.map(cat => 
      `<a href="#" data-categoria="${cat === 'Todas' ? '' : cat}">${cat}</a>`
    ).join('');

    cont.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', e => {
        e.preventDefault();
        const categoria = a.getAttribute('data-categoria');
        const nuevaURL = categoria ? `?categoria=${encodeURIComponent(categoria)}` : 'intercambio.php';
        window.history.pushState({}, '', nuevaURL);
        cargarProductos(categoria);
      });
    });

    const params = new URLSearchParams(window.location.search);
    const categoriaInicial = params.get('categoria');
    await cargarProductos(categoriaInicial);

  } catch (err) {
    console.error("Error al cargar categorías:", err);
    cont.innerHTML = "<a style='color:red;'>Error al cargar categorías</a>";
  }
});


async function cargarProductos(categoria = null) {
  const productosContainer = document.getElementById('productosContainer');
  const url = categoria
    ? `php/controller.php?get=productos&categoria=${encodeURIComponent(categoria)}`
    : 'php/controller.php?get=productos';

  try {
    const productos = await fetchJSON(url);
    console.log("Productos recibidos:", productos);

    if (!productos || productos.length === 0) {
      productosContainer.innerHTML = `<p style="color:red;font-weight:bold;">No hay productos disponibles.</p>`;
      return;
    }

    productosContainer.innerHTML = productos.map(p => `
      <div class="producto">
        <a href="detalle.php?id=${p.id_producto}" class="producto-link">
          <img src="${p.foto || 'img/default.png'}" alt="${p.nombre}">
          <p class="nombre-producto">${p.nombre ?? ''}</p>
          <p class="estado-producto"><em>${p.estado === 'Disponible' ? 'Disponible' : 'En intercambio'}</em></p>
        </a>
      </div>
    `).join('');

  } catch (err) {
    console.error('Error productos:', err);
    productosContainer.innerHTML = '<p>Error al cargar productos.</p>';
  }
}
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
