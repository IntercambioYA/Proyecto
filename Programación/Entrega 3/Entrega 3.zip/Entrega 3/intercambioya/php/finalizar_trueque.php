<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['id_usuario'])) {
    header("Location: ../index.php");
    exit;
}

$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}

$id_trueque = (int)($_GET['id'] ?? 0);
$accion = $_GET['accion'] ?? '';
$id_usuario = $_SESSION['id_usuario'];

if (!$id_trueque) {
    $mysqli->close();
    die("Falta el ID del trueque.");
}


$sel = $mysqli->prepare("SELECT id_chat FROM Chat WHERE id_trueque = ?");
$sel->bind_param("i", $id_trueque);
$sel->execute();
$row = $sel->get_result()->fetch_assoc();
$sel->close();
$id_chat = $row['id_chat'] ?? 0;


if ($accion === 'confirmar') {
    
    $check = $mysqli->prepare("SELECT id_usuario FROM Confirmacion_Trueque WHERE id_trueque = ? AND id_usuario = ?");
    $check->bind_param("ii", $id_trueque, $id_usuario);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();

    if (!$exists) {
        
        $insert = $mysqli->prepare("INSERT INTO Confirmacion_Trueque (id_trueque, id_usuario, fecha) VALUES (?, ?, NOW())");
        $insert->bind_param("ii", $id_trueque, $id_usuario);
        $insert->execute();
        $insert->close();

        
        $up = $mysqli->prepare("UPDATE Trueque SET confirmaciones = confirmaciones + 1 WHERE id_trueque = ?");
        $up->bind_param("i", $id_trueque);
        $up->execute();
        $up->close();
    }

    
    $sel2 = $mysqli->prepare("SELECT confirmaciones FROM Trueque WHERE id_trueque = ?");
    $sel2->bind_param("i", $id_trueque);
    $sel2->execute();
    $res = $sel2->get_result()->fetch_assoc();
    $sel2->close();

    $confirmaciones = $res['confirmaciones'] ?? 0;

   
    if ($confirmaciones >= 2) {
        $stmt = $mysqli->prepare("UPDATE Trueque SET estado = 'Finalizado' WHERE id_trueque = ?");
        $stmt->bind_param("i", $id_trueque);
        $stmt->execute();
        $stmt->close();

        
        $sel = $mysqli->prepare("SELECT id_producto_ofrecido, id_producto_objetivo FROM Trueque WHERE id_trueque = ?");
        $sel->bind_param("i", $id_trueque);
        $sel->execute();
        $prod = $sel->get_result()->fetch_assoc();
        $sel->close();

        if ($prod) {
            $upd = $mysqli->prepare("UPDATE Producto SET estado = 'Intercambiado' WHERE id_producto IN (?, ?)");
            $upd->bind_param("ii", $prod['id_producto_ofrecido'], $prod['id_producto_objetivo']);
            $upd->execute();
            $upd->close();
        }

        echo "<script>
                alert('Ambos usuarios confirmaron el trueque. ¡Intercambio completado!');
                window.location='../chat.php?id_chat=$id_chat';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('Tu confirmación fue registrada. Esperando la otra parte (1/2).');
                window.location='../chat.php?id_chat=$id_chat';
              </script>";
        exit;
    }
}


if ($accion === 'cancelar') {
    $stmt = $mysqli->prepare("UPDATE Trueque SET estado = 'Cancelado' WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $stmt->close();

    echo "<script>
            alert('Trueque cancelado correctamente.');
            window.location='../chat.php?id_chat=$id_chat';
          </script>";
    exit;
}

echo "<script>alert('Acción inválida.'); window.location='../chats.php';</script>";
$mysqli->close();
exit;
?>
