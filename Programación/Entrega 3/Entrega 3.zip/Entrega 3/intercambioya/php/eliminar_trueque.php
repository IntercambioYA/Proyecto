<?php
session_start();
if (empty($_SESSION['id_usuario'])) {
    header("Location: ../index.php");
    exit;
}

$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error DB: " . $mysqli->connect_error);
}

$id_trueque = (int)($_GET['id'] ?? 0);
$id_usuario = $_SESSION['id_usuario'];

if ($id_trueque > 0) {
    
    $stmt = $mysqli->prepare("SELECT id_usuario1, id_usuario2 FROM Trueque WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($res && ($res['id_usuario1'] == $id_usuario || $res['id_usuario2'] == $id_usuario)) {
        $stmt = $mysqli->prepare("DELETE FROM Trueque WHERE id_trueque = ?");
        $stmt->bind_param("i", $id_trueque);
        $stmt->execute();
        $stmt->close();

        echo "<script>alert('Trueque eliminado correctamente.'); window.location='../mis_trueques.php';</script>";
    } else {
        echo "<script>alert('No tienes permiso para eliminar este trueque.'); window.history.back();</script>";
    }
}

$mysqli->close();
?>
