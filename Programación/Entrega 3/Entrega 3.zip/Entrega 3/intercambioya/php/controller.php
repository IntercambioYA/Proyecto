<?php
session_start();


$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "root";
$DB_NAME = "IntercambioYA";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}

function registrar_accion_admin($accion, $detalle) {
    if (!is_dir(__DIR__ . "/../logs")) {
        mkdir(__DIR__ . "/../logs", 0755, true);
    }
    $ruta_log = __DIR__ . "/../logs/admin_log.txt";
    $fecha = date("Y-m-d H:i:s");
    $admin = $_SESSION['primer_nombre'] ?? 'Desconocido';
    $entrada = "[$fecha] ($admin) $accion - $detalle" . PHP_EOL;
    file_put_contents($ruta_log, $entrada, FILE_APPEND | LOCK_EX);
}



if (!function_exists('js_alert_and_redirect')) {
    function js_alert_and_redirect($msg, $location = null) {
        echo "<script>";
        echo "alert(" . json_encode($msg) . ");";
        if ($location) {
            echo "window.location.href=" . json_encode($location) . ";";
        } else {
            echo "window.history.back();";
        }
        echo "</script>";
        exit;
    }
}


$action = $_POST['action'] ?? $_GET['action'] ?? null;


if ($action === 'register') {
    $primer_nombre = trim($_POST['primer_nombre'] ?? '');
    $primer_apellido = trim($_POST['primer_apellido'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $clave = $_POST['clave'] ?? '';

    if (!$primer_nombre || !$primer_apellido || !$email || !$clave) {
        js_alert_and_redirect("Por favor completa todos los campos.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        js_alert_and_redirect("El correo no es válido.");
    }

    $stmt = $mysqli->prepare("SELECT id_usuario FROM Usuario WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        js_alert_and_redirect("El correo ya está registrado. Inicia sesión.");
    }
    $stmt->close();

    $hash = password_hash($clave, PASSWORD_DEFAULT);

    $stmt = $mysqli->prepare("
        INSERT INTO Usuario (primer_nombre, primer_apellido, email, contraseña, rol, fecha_registro)
        VALUES (?, ?, ?, ?, 'Registrado', NOW())
    ");
    $stmt->bind_param("ssss", $primer_nombre, $primer_apellido, $email, $hash);
    if (!$stmt->execute()) {
        js_alert_and_redirect("Error al registrar usuario: " . $stmt->error);
    }
    $id_usuario = $stmt->insert_id;
    $stmt->close();

    if (!empty($telefono)) {
        $stmt2 = $mysqli->prepare("INSERT INTO Telefono_usuario (id_usuario, numero) VALUES (?, ?)");
        $stmt2->bind_param("is", $id_usuario, $telefono);
        $stmt2->execute();
        $stmt2->close();
    }

    $_SESSION['id_usuario'] = $id_usuario;
    $_SESSION['primer_nombre'] = $primer_nombre;
    $_SESSION['email'] = $email;
    $_SESSION['rol'] = 'Registrado';

    js_alert_and_redirect("Registro exitoso. Bienvenido $primer_nombre", "../intercambio.php");
}


if ($action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $clave = $_POST['clave'] ?? '';

    if (!$email || !$clave) {
        js_alert_and_redirect("Completa email y contraseña.");
    }

    $stmt = $mysqli->prepare("SELECT id_usuario, primer_nombre, contraseña, rol FROM Usuario WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if (!$res || $res->num_rows === 0) {
        js_alert_and_redirect("Usuario no encontrado.");
    }

    $user = $res->fetch_assoc();
    $stmt->close();

    if (password_verify($clave, $user['contraseña'])) {
        $_SESSION['id_usuario'] = $user['id_usuario'];
        $_SESSION['primer_nombre'] = $user['primer_nombre'];
        $_SESSION['email'] = $email;
        $_SESSION['rol'] = $user['rol'];

        if (strtolower($user['rol']) === 'administrador') {
            js_alert_and_redirect("Bienvenido Administrador " . $user['primer_nombre'], "../admin_panel.php");
        } else {
            js_alert_and_redirect("Bienvenido " . $user['primer_nombre'], "../intercambio.php");
        }
    } else {
        js_alert_and_redirect("Contraseña incorrecta.");
    }
}


if ($action === 'logout') {
    session_unset();
    session_destroy();
    js_alert_and_redirect("Sesión cerrada correctamente.", "../index.php");
}



if ($action === 'upload_product') {
    if (empty($_SESSION['id_usuario'])) {
        js_alert_and_redirect("Tenés que iniciar sesión para subir un producto.", "../index.php");
    }

    $id_usuario = $_SESSION['id_usuario'];
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $categoria_nombre = trim($_POST['categoria'] ?? '');
    $condicion = trim($_POST['condicion'] ?? '');

    if (!$nombre || !$descripcion || !$categoria_nombre || !$condicion) {
        js_alert_and_redirect("Faltan campos obligatorios.");
    }

    if (!empty($_FILES['imagen']['name'])) {
        $fileSize = $_FILES['imagen']['size'];
        $fileType = mime_content_type($_FILES['imagen']['tmp_name']);
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];

        if ($fileSize > 2 * 1024 * 1024) js_alert_and_redirect("La imagen es demasiado grande (máx. 2 MB).");
        if (!in_array($fileType, $allowedTypes)) js_alert_and_redirect("Formato no permitido. Usa JPG, PNG o WEBP.");
    }

    $foto_path = null;
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . "/../img/uploads/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

        $origName = basename($_FILES['imagen']['name']);
        $safeName = time() . "_" . bin2hex(random_bytes(3)) . "_" . preg_replace('/[^A-Za-z0-9_\.-]/', '_', $origName);
        $dest = $uploadDir . $safeName;

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $dest)) {
            $foto_path = "img/uploads/" . $safeName;
        }
    }

    $estado = "Disponible";

    $stmtCat = $mysqli->prepare("SELECT id_categoria FROM Categoria WHERE nombre = ?");
    $stmtCat->bind_param("s", $categoria_nombre);
    $stmtCat->execute();
    $resCat = $stmtCat->get_result()->fetch_assoc();
    $stmtCat->close();

    if (!$resCat) js_alert_and_redirect("Categoría no válida.");
    $id_categoria = $resCat['id_categoria'];

    $stmt = $mysqli->prepare("
        INSERT INTO Producto (id_usuario, id_categoria, nombre, estado, condicion, foto, descripcion)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iisssss", $id_usuario, $id_categoria, $nombre, $estado, $condicion, $foto_path, $descripcion);

    if ($stmt->execute()) {
        js_alert_and_redirect("Producto publicado correctamente.", "../intercambio.php");
    } else {
        js_alert_and_redirect("Error al publicar producto: " . $stmt->error);
    }
    $stmt->close();
}


if (isset($_GET['get']) && $_GET['get'] === 'categorias') {
    header('Content-Type: application/json; charset=utf-8');

    $categorias = [];
    $result = $mysqli->query("SELECT nombre FROM Categoria ORDER BY nombre ASC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $categorias[] = $row['nombre'];
        }
        $result->close();
    }

    echo json_encode($categorias, JSON_UNESCAPED_UNICODE);
    exit;
}


if (isset($_GET['get']) && $_GET['get'] === 'productos') {
    header('Content-Type: application/json; charset=utf-8');
    $categoria = $_GET['categoria'] ?? null;

    $sqlBase = "
        SELECT 
            p.id_producto, 
            p.nombre, 
            p.foto, 
            p.descripcion, 
            p.estado, 
            c.nombre AS categoria
        FROM Producto p
        LEFT JOIN Categoria c ON p.id_categoria = c.id_categoria
        WHERE p.estado = 'Disponible'
    ";

    if (!empty($categoria)) {
        $sqlBase .= " AND c.nombre = ?";
        $stmt = $mysqli->prepare($sqlBase . " ORDER BY p.id_producto DESC");
        $stmt->bind_param("s", $categoria);
        $stmt->execute();
        $res = $stmt->get_result();
    } else {
        $res = $mysqli->query($sqlBase . " ORDER BY p.id_producto DESC");
    }

    $productos = [];
    while ($row = $res->fetch_assoc()) {
        $productos[] = [
            'id_producto' => $row['id_producto'],
            'nombre' => $row['nombre'],
            'foto' => $row['foto'] ?: 'img/default-product.png',
            'estado' => $row['estado'],
            'categoria' => $row['categoria'] ?? 'Sin categoría'
        ];
    }

    echo json_encode($productos, JSON_UNESCAPED_UNICODE);
    exit;
}


if ($action === 'eliminar_producto') {
    if (empty($_SESSION['id_usuario'])) {
        js_alert_and_redirect("No autorizado.", "../index.php");
    }

    $id_producto = (int)($_POST['id_producto'] ?? 0);
    $id_usuario = $_SESSION['id_usuario'];

    $stmt = $mysqli->prepare("SELECT foto FROM Producto WHERE id_producto = ? AND id_usuario = ?");
    $stmt->bind_param("ii", $id_producto, $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res && file_exists(__DIR__ . '/../' . $res['foto'])) {
        unlink(__DIR__ . '/../' . $res['foto']);
    }
    $stmt->close();

    $stmt = $mysqli->prepare("DELETE FROM Producto WHERE id_producto = ? AND id_usuario = ?");
    $stmt->bind_param("ii", $id_producto, $id_usuario);
    if ($stmt->execute()) {
        js_alert_and_redirect("Producto eliminado correctamente.", "../perfil.php");
    } else {
        js_alert_and_redirect("Error al eliminar producto.", "../perfil.php");
    }
    $stmt->close();
}


if ($action === 'reportar_usuario') {
    if (empty($_SESSION['id_usuario'])) {
        js_alert_and_redirect("Tenés que iniciar sesión para reportar a un usuario.", "../index.php");
    }

    $id_reportante = $_SESSION['id_usuario'];
    $id_reportado = (int)($_POST['id_reportado'] ?? 0);
    $motivo = trim($_POST['motivo'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');

    if (!$id_reportado || !$motivo) {
        js_alert_and_redirect("Debes seleccionar un motivo para el reporte.");
    }

    if ($id_reportante === $id_reportado) {
        js_alert_and_redirect("No podés reportarte a vos mismo.");
    }

    $stmt = $mysqli->prepare("
        INSERT INTO Reporte (id_reportante, id_reportado, motivo, descripcion, fecha_reporte)
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("iiss", $id_reportante, $id_reportado, $motivo, $descripcion);

    if ($stmt->execute()) {
        js_alert_and_redirect("Reporte enviado. Nuestro equipo lo revisará.", "../perfil_usuario.php?id=$id_reportado");
    } else {
        js_alert_and_redirect("Error al enviar el reporte: " . $stmt->error);
    }
    $stmt->close();
}

if ($action === 'editar_perfil') {
    if (empty($_SESSION['id_usuario'])) {
        js_alert_and_redirect("Tenés que iniciar sesión para editar tu perfil.", "../index.php");
    }

    $id_usuario = $_SESSION['id_usuario'];
    $nombre = trim($_POST['primer_nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

   
    $foto_sql = "";
    $rutaRelativa = "";

    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['foto_perfil'];
        $fileType = mime_content_type($file['tmp_name']);
        $allowed = ['image/jpeg', 'image/png', 'image/webp'];

        if (in_array($fileType, $allowed)) {
            $uploadDir = __DIR__ . "/../img/perfiles/";
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $newName = "perfil_" . $id_usuario . "_" . time() . "." . $ext;
            $destino = $uploadDir . $newName;

            if (move_uploaded_file($file['tmp_name'], $destino)) {
                $rutaRelativa = "img/perfiles/" . $newName;

                
                $res = $mysqli->query("SELECT foto_perfil FROM Usuario WHERE id_usuario = $id_usuario");
                if ($res && $old = $res->fetch_assoc()) {
                    $oldPath = __DIR__ . '/../' . $old['foto_perfil'];
                    if (!empty($old['foto_perfil']) && file_exists($oldPath)) {
                        unlink($oldPath);
                    }
                }

                $foto_sql = ", foto_perfil = '$rutaRelativa'";
            }
        }
    }

   
    if (!empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE Usuario 
                SET primer_nombre = ?, primer_apellido = ?, email = ?, contraseña = ? $foto_sql
                WHERE id_usuario = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ssssi", $nombre, $apellido, $email, $hash, $id_usuario);
    } else {
        $sql = "UPDATE Usuario 
                SET primer_nombre = ?, primer_apellido = ?, email = ? $foto_sql
                WHERE id_usuario = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("sssi", $nombre, $apellido, $email, $id_usuario);
    }

    
    if ($stmt->execute()) {
        $_SESSION['primer_nombre'] = $nombre;
        $_SESSION['apellido'] = $apellido;
        $_SESSION['email'] = $email;
        if (!empty($rutaRelativa)) {
            $_SESSION['foto_perfil'] = $rutaRelativa;
        }

        js_alert_and_redirect("Perfil actualizado correctamente.", "../perfil.php");
    } else {
        js_alert_and_redirect("Error al actualizar perfil.", "../perfil.php");
    }

    $stmt->close();
    exit;
}

if ($action === 'reportar_usuario') {
    if (empty($_SESSION['id_usuario'])) {
        js_alert_and_redirect("Tenés que iniciar sesión para enviar un reporte.", "../index.php");
    }

    $id_reportante = $_SESSION['id_usuario'];
    $id_reportado = intval($_POST['id_reportado']);
    $motivo = trim($_POST['motivo']);
    $descripcion = trim($_POST['descripcion'] ?? '');

    if (empty($motivo)) {
        js_alert_and_redirect("Debés seleccionar un motivo para el reporte.", "../perfil.php");
    }

    
    $mysqli->query("CREATE TABLE IF NOT EXISTS Reporte (
        id_reporte INT AUTO_INCREMENT PRIMARY KEY,
        id_reportante INT NOT NULL,
        id_reportado INT NOT NULL,
        motivo VARCHAR(255) NOT NULL,
        descripcion TEXT,
        fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_reportante) REFERENCES Usuario(id_usuario),
        FOREIGN KEY (id_reportado) REFERENCES Usuario(id_usuario)
    )");

    
    $stmt = $mysqli->prepare("
        INSERT INTO Reporte (id_reportante, id_reportado, motivo, descripcion)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->bind_param("iiss", $id_reportante, $id_reportado, $motivo, $descripcion);
    $stmt->execute();
    $stmt->close();

    js_alert_and_redirect(" Reporte enviado correctamente. El equipo revisará la situación.", "../perfil.php");
}



if ($action === 'eliminar_usuario') {
    if (strtolower($_SESSION['rol'] ?? '') !== 'administrador') {
        js_alert_and_redirect("No tenés permisos para realizar esta acción.", "../index.php");
    }

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $check = $mysqli->prepare("SELECT rol FROM Usuario WHERE id_usuario = ?");
        $check->bind_param("i", $id);
        $check->execute();
        $rol = $check->get_result()->fetch_assoc()['rol'] ?? '';
        $check->close();

        if (strtolower($rol) === 'administrador') {
            js_alert_and_redirect("No se puede eliminar a otro administrador.", "../admin_panel.php");
        }

        $mysqli->query("DELETE FROM Reporte WHERE id_reportado = $id OR id_reportante = $id");
        $mysqli->query("DELETE FROM Producto WHERE id_usuario = $id");
        $mysqli->query("DELETE FROM Mensaje WHERE id_usuario = $id");
        $mysqli->query("DELETE FROM Chat WHERE id_usuario1 = $id OR id_usuario2 = $id");

        $stmt = $mysqli->prepare("DELETE FROM Usuario WHERE id_usuario = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        registrar_accion_admin("Eliminar usuario", "ID: $id");
        js_alert_and_redirect("Usuario eliminado correctamente.", "../admin_panel.php");

    } else {
        js_alert_and_redirect("ID inválido.", "../admin_panel.php");
    }
}


if ($action === 'eliminar_producto_admin') {
    if (strtolower($_SESSION['rol'] ?? '') !== 'administrador') {
        js_alert_and_redirect("No tenés permisos para realizar esta acción.", "../index.php");
    }

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $stmt = $mysqli->prepare("DELETE FROM Producto WHERE id_producto = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        registrar_accion_admin("Eliminar producto", "ID: $id");
        js_alert_and_redirect("Producto eliminado correctamente.", "../admin_panel.php");

    } else {
        js_alert_and_redirect("ID inválido.", "../admin_panel.php");
    }
}


if ($action === 'eliminar_reporte') {
    if (strtolower($_SESSION['rol'] ?? '') !== 'administrador') {
        js_alert_and_redirect("No tenés permisos para realizar esta acción.", "../index.php");
    }

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $stmt = $mysqli->prepare("DELETE FROM Reporte WHERE id_reporte = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        registrar_accion_admin("Eliminar reporte", "ID: $id");
        js_alert_and_redirect("Reporte eliminado correctamente.", "../admin_panel.php");

    } else {
        js_alert_and_redirect("ID inválido.", "../admin_panel.php");
    }
}


if ($action === 'eliminar_chat') {
    if (strtolower($_SESSION['rol'] ?? '') !== 'administrador') {
        js_alert_and_redirect("No tenés permisos para realizar esta acción.", "../index.php");
    }

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        $mysqli->query("DELETE FROM Mensaje WHERE id_chat = $id");
        $stmt = $mysqli->prepare("DELETE FROM Chat WHERE id_chat = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        registrar_accion_admin("Eliminar chat", "ID: $id");
        js_alert_and_redirect("Chat eliminado correctamente.", "../admin_panel.php");

    } else {
        js_alert_and_redirect("ID inválido.", "../admin_panel.php");
    }
}

$mysqli->close();
?>