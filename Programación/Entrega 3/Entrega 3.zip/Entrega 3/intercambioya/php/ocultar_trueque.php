<?php
session_start();
if (empty($_SESSION['id_usuario'])) {
  header("Location: ../index.php");
  exit;
}

$id_trueque = (int)($_POST['id_trueque'] ?? 0);


$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "root";
$DB_NAME = "IntercambioYA";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) die("DB error: " . $mysqli->connect_error);


if ($id_trueque <= 0) {
  $mysqli->close();
  echo "<script>alert('ID de trueque inválido.');window.location='../mis_trueques.php';</script>";
  exit;
}


$stmt = $mysqli->prepare("UPDATE Trueque SET visible_usuario = 0 WHERE id_trueque = ?");
$stmt->bind_param("i", $id_trueque);
$stmt->execute();
$stmt->close();

$mysqli->close();

echo "<script>alert('Trueque eliminado de tu vista.');window.location='../mis_trueques.php';</script>";
?>
