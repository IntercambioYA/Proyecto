<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['id_usuario'])) {
    header("Location: ../index.php");
    exit;
}

$id_usuario = $_SESSION['id_usuario'];
$id_chat = (int)($_GET['id'] ?? 0);

if (!$id_chat) {
    die("ID de chat inválido.");
}


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}


$stmt = $mysqli->prepare("
    SELECT id_usuario1, id_usuario2 
    FROM Chat 
    WHERE id_chat = ?
");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$chat = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$chat) {
    $mysqli->close();
    die("El chat no existe.");
}



if ($id_usuario == $chat['id_usuario1']) {
    $campo = "visible_para_usuario1";
} elseif ($id_usuario == $chat['id_usuario2']) {
    $campo = "visible_para_usuario2";
} else {
    $mysqli->close();
    die("No tienes permiso para eliminar este chat.");
}


$query = "UPDATE Chat SET $campo = 0 WHERE id_chat = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$stmt->close();

$mysqli->close();


echo "<script>
    alert('🗑️ El chat se eliminó de tu vista, pero sigue guardado en el sistema.');
    window.location='../chats.php';
</script>";
exit;
?>
