<?php
session_start();


$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "root";
$DB_NAME = "IntercambioYA";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) {
    die("Error DB: " . $mysqli->connect_error);
}


if (empty($_SESSION['id_usuario'])) {
    die("Debes iniciar sesión para ofrecer un trueque.");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'ofrecer_trueque') {
    $id_producto_ofrecido = (int)($_POST['id_producto_ofrecido'] ?? 0);
    $id_producto_objetivo = (int)($_POST['id_producto_objetivo'] ?? 0);
    $id_usuario_ofertante = $_SESSION['id_usuario'];

    
    if ($id_producto_ofrecido <= 0 || $id_producto_objetivo <= 0) {
        echo "<script>alert('Error: datos de producto inválidos.');window.history.back();</script>";
        exit;
    }

    
    $stmt = $mysqli->prepare("SELECT id_usuario FROM Producto WHERE id_producto = ?");
    $stmt->bind_param("i", $id_producto_objetivo);
    $stmt->execute();
    $producto_obj = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    
    $stmt = $mysqli->prepare("SELECT id_usuario FROM Producto WHERE id_producto = ?");
    $stmt->bind_param("i", $id_producto_ofrecido);
    $stmt->execute();
    $producto_of = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    
    if (!$producto_obj || !$producto_of) {
        echo "<script>alert('Error: uno de los productos no existe.');window.history.back();</script>";
        exit;
    }

    $id_usuario_receptor = $producto_obj['id_usuario'];

    
    if ($id_usuario_receptor == $id_usuario_ofertante) {
        echo "<script>alert('No puedes ofrecer un trueque con tu propio producto.');window.history.back();</script>";
        exit;
    }

   
    $stmt = $mysqli->prepare("
        INSERT INTO Trueque (estado, id_usuario1, id_usuario2, id_producto_ofrecido, id_producto_objetivo, fecha_creacion)
        VALUES ('Pendiente', ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("iiii", $id_usuario_ofertante, $id_usuario_receptor, $id_producto_ofrecido, $id_producto_objetivo);
    $stmt->execute();
    $stmt->close();

    $mysqli->close();

    echo "<script>alert('Trueque ofrecido correctamente. Esperando respuesta del otro usuario.');window.location='../mis_trueques.php';</script>";
    exit;
}

die('Acción no válida.');
?>
