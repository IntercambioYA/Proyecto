<?php
session_start();

if (empty($_SESSION['id_usuario'])) {
    header("Location: ../index.php");
    exit;
}

$id_usuario = $_SESSION['id_usuario'];


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error DB: " . $mysqli->connect_error);
}

$id_trueque = (int)($_GET['id'] ?? 0);
$accion = $_GET['accion'] ?? '';

if (!$id_trueque || !in_array($accion, ['aceptar', 'rechazar'])) {
    die("Acción o ID inválidos.");
}


$stmt = $mysqli->prepare("
    SELECT id_usuario1 AS id_usuario_ofertante, 
           id_usuario2 AS id_usuario_receptor, 
           estado
    FROM Trueque
    WHERE id_trueque = ?
");
$stmt->bind_param("i", $id_trueque);
$stmt->execute();
$trueque = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$trueque) {
    die("Trueque no encontrado.");
}


if ($trueque['id_usuario_receptor'] != $id_usuario) {
    die("No tienes permiso para gestionar este trueque.");
}


if ($accion === 'aceptar') {
    
    $stmt = $mysqli->prepare("UPDATE Trueque SET estado = 'Aceptado' WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $stmt->close();

  
    $stmt = $mysqli->prepare("SELECT id_chat FROM Chat WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$res) {
        $stmt = $mysqli->prepare("
            INSERT INTO Chat (id_trueque, id_usuario1, id_usuario2, fecha_inicio)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param(
            "iii", 
            $id_trueque, 
            $trueque['id_usuario_ofertante'], 
            $trueque['id_usuario_receptor']
        );
        $stmt->execute();
        $stmt->close();
    }

    echo "<script>alert('Trueque aceptado. Se creó un chat para ambos usuarios.'); window.location='../chats.php';</script>";
    exit;
}


if ($accion === 'rechazar') {
    
    $stmt = $mysqli->prepare("UPDATE Trueque SET estado = 'Rechazado' WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $stmt->close();

   
    $stmt = $mysqli->prepare("SELECT id_chat FROM Chat WHERE id_trueque = ?");
    $stmt->bind_param("i", $id_trueque);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($res && isset($res['id_chat'])) {
        $id_chat = $res['id_chat'];
        $mysqli->query("DELETE FROM Mensaje WHERE id_chat = $id_chat");
        $mysqli->query("DELETE FROM Chat WHERE id_chat = $id_chat");
    }

    echo "<script>alert('Trueque rechazado correctamente.'); window.location='../mis_trueques.php';</script>";
    exit;
}

$mysqli->close();
?>
