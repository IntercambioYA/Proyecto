document.addEventListener("DOMContentLoaded", function () {
  // Simulamos carga de usuario
  const usuario = JSON.parse(localStorage.getItem("usuarioActivo")) || {
    nombre: "Santiago Quirque",
    email: "ejemplo@correo.com",
    telefono: "+59800000000",
    bio: "Me encantan los intercambios responsables.",
    fecha: "2024-01-01",
    foto: "img/default-user.png"
  };

  document.getElementById("foto-perfil").src = usuario.foto;
  document.getElementById("nombre-perfil").textContent = usuario.nombre;
  document.getElementById("email-perfil").textContent = usuario.email;
  document.getElementById("telefono-perfil").textContent = usuario.telefono;
  document.getElementById("bio-perfil").textContent = usuario.bio;
  document.getElementById("fecha-registro").textContent = usuario.fecha;

  // Mostrar productos subidos por el usuario
  const productos = JSON.parse(localStorage.getItem("productos")) || [];
  const contenedor = document.getElementById("misProductos");
  const propios = productos.filter(p => p.email === usuario.email);

  if (propios.length === 0) {
    contenedor.innerHTML = "<p>No has publicado ningún producto todavía.</p>";
    return;
  }

  propios.forEach(p => {
    const div = document.createElement("div");
    div.className = "producto";
    div.innerHTML = `
      <img src="${p.imagen}" alt="${p.nombre}" />
      <p>${p.nombre}</p>
    `;
    contenedor.appendChild(div);
  });
});

function cerrarSesion() {
  localStorage.removeItem("usuarioActivo");
  window.location.href = "index.html";
}

function eliminarCuenta() {
  if (confirm("¿Seguro que querés eliminar tu cuenta? Esta acción no se puede deshacer.")) {
    localStorage.removeItem("usuarioActivo");
    alert("Cuenta eliminada.");
    window.location.href = "index.html";
  }
}

function editarPerfil() {
  alert("Función editar perfil aún no implementada.");
}
