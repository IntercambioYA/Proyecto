document.addEventListener("DOMContentLoaded", function () {
  const producto = JSON.parse(localStorage.getItem("productoDetalle"));
  if (producto) {
    document.getElementById("detalle-nombre").textContent = producto.nombre;
    document.getElementById("detalle-imagen").src = producto.imagen;
    document.getElementById("detalle-imagen").alt = producto.nombre;
    document.getElementById("detalle-categoria").textContent = producto.categoria;
    document.getElementById("detalle-intercambio").textContent = producto.intercambio;
    document.getElementById("detalle-contacto").textContent = producto.email;
    document.getElementById("detalle-descripcion").textContent = producto.descripcion;
  }
});