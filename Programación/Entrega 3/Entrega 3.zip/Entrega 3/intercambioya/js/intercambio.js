document.addEventListener("DOMContentLoaded", function() {
  const container = document.getElementById("productosContainer");
  const productos = JSON.parse(localStorage.getItem("productos")) || [];

  productos.forEach((prod, index) => {
    const div = document.createElement("div");
    div.className = "producto";
    div.innerHTML = `
      <img src="${prod.imagen}" alt="${prod.nombre}">
      <h3>${prod.nombre}</h3>
    `;
    div.onclick = () => {
      localStorage.setItem("productoDetalle", JSON.stringify(prod));
      window.location.href = "detalle.html";
    };
    container.appendChild(div);
  });
});