<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuario_actual = $_SESSION['primer_nombre'] ?? null;


$id_usuario = (int)($_GET['id'] ?? 0);
if ($id_usuario <= 0) {
  echo "Usuario no válido.";
  exit;
}


$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "root";
$DB_NAME = "IntercambioYA";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) die("DB error: " . $mysqli->connect_error);


if (isset($_SESSION['id_usuario']) && $_SESSION['id_usuario'] == $id_usuario) {
  header("Location: perfil.php");
  exit;
}


$stmt = $mysqli->prepare("SELECT primer_nombre, primer_apellido, email, foto_perfil FROM Usuario WHERE id_usuario = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$res = $stmt->get_result();
$usuario = $res->fetch_assoc();
$stmt->close();

if (!$usuario) {
  echo "Usuario no encontrado.";
  exit;
}


if (!isset($_SESSION['pagina_origen'])) {
    $_SESSION['pagina_origen'] = $_SERVER['HTTP_REFERER'] ?? 'intercambio.php';
}
if (basename($_SERVER['PHP_SELF']) === 'index.php' || basename($_SERVER['PHP_SELF']) === 'intercambio.php') {
    $_SESSION['pagina_origen'] = $_SERVER['PHP_SELF'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Perfil de <?= htmlspecialchars($usuario['primer_nombre']) ?></title>
  <link rel="stylesheet" href="css/perfil.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/responsive.css" />
  <link rel="stylesheet" href="css/reporte.css" />
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

  <style>
    
    .centrar-boton { text-align: center; margin: 2rem 0; }
    .btn-reportar {
      background-color: #dc3545;
      color: white;
      border: none;
      padding: 12px 30px;
      border-radius: 10px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: 0.3s;
    }
    .btn-reportar:hover { background-color: #b02a37; transform: scale(1.05); }

    .modal-reporte {
      display: none;
      position: fixed;
      z-index: 2000;
      left: 0; top: 0;
      width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.6);
      justify-content: center;
      align-items: center;
    }
    .modal-contenido {
      background: white;
      border-radius: 12px;
      padding: 2rem;
      width: 90%;
      max-width: 420px;
      text-align: center;
      box-shadow: 0 0 15px rgba(0,0,0,0.3);
      animation: fadeIn 0.3s ease;
    }
    @keyframes fadeIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
    .modal-contenido h3 { color: #0A66C2; margin-bottom: 1rem; }
    .modal-contenido select, .modal-contenido textarea {
      width: 100%;
      padding: 0.7rem;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-family: inherit;
      margin-bottom: 1rem;
    }
    .botones-modal { display: flex; justify-content: space-between; }
    .btn-cancelar, .btn-enviar {
      border: none; border-radius: 8px; padding: 10px 15px; cursor: pointer; transition: 0.3s;
    }
    .btn-cancelar { background: #6c757d; color: white; }
    .btn-cancelar:hover { background: #5a6268; }
    .btn-enviar { background: #dc3545; color: white; }
    .btn-enviar:hover { background: #b02a37; }
    footer.footer {
      background-color: #0A66C2;
      color: white;
      text-align: center;
      padding: 2rem 1rem;
      margin-top: 4rem;
      position: relative;
      bottom: 0;
      width: 100%;
    }
  </style>
</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo" />
    <a href="<?= htmlspecialchars($_SESSION['pagina_origen'] ?? 'intercambio.php') ?>" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <?php if (isset($_SESSION['id_usuario'])): ?>
      <?php if (strcasecmp($_SESSION['rol'] ?? '', 'Administrador') === 0): ?>
      
        <a href="admin_panel.php"> Panel de administración</a>
        <a href="intercambio.php"> Productos</a>
        <a href="chats.php"> Vigilar Chats</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php else: ?>
        
        <a href="mis_trueques.php">Mis Intercambios</a>
        <a href="chats.php" class="active">Chats</a>
        <a href="perfil.php">Mi perfil</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php endif; ?>
    <?php else: ?>
      
      <a href="index.php">Inicio</a>
      <a href="#" onclick="abrirModal('modalLogin')">Iniciar sesión</a>
    <?php endif; ?>
  </nav>
</header>
<main class="perfil-contenedor">
  <div class="perfil-box">
    <img src="<?= htmlspecialchars($usuario['foto_perfil'] ?? 'img/default-user.png') ?>" alt="Foto de perfil" class="foto-perfil">
    <h1><?= htmlspecialchars($usuario['primer_nombre'] . " " . $usuario['primer_apellido']) ?></h1>
    <p class="correo"><?= htmlspecialchars($usuario['email']) ?></p>
  </div>

  
  <section class="mis-productos">
    <h2>Productos disponibles</h2>
    <div class="productos-grid">
      <?php
        $stmt = $mysqli->prepare("
          SELECT id_producto, nombre, foto 
          FROM Producto 
          WHERE id_usuario = ? AND estado = 'Disponible'
          ORDER BY id_producto DESC
        ");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0):
          while ($p = $res->fetch_assoc()): ?>
            <div class="producto-card">
              <img src="<?= htmlspecialchars($p['foto'] ?: 'img/default-product.png') ?>" alt="Producto">
              <p><strong><?= htmlspecialchars($p['nombre']) ?></strong></p>
              <a href="detalle.php?id=<?= $p['id_producto'] ?>" class="btn-ver">Ver</a>
            </div>
      <?php endwhile;
        else: ?>
          <p style="text-align:center;color:#777;">No hay productos disponibles.</p>
      <?php endif;
        $stmt->close();
      ?>
    </div>
  </section>

  
  <section class="mis-productos">
    <h2>Productos intercambiados</h2>
    <div class="productos-grid">
      <?php
        $stmt = $mysqli->prepare("
          SELECT id_producto, nombre, foto 
          FROM Producto 
          WHERE id_usuario = ? AND estado = 'Intercambiado'
          ORDER BY id_producto DESC
        ");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0):
          while ($p = $res->fetch_assoc()): ?>
            <a href="detalle.php?id=<?= $p['id_producto'] ?>" class="producto-card intercambiado">
              <div class="overlay"><span>Intercambiado</span></div>
              <img src="<?= htmlspecialchars($p['foto'] ?: 'img/default-product.png') ?>" alt="Producto intercambiado">
              <p><strong><?= htmlspecialchars($p['nombre']) ?></strong></p>
            </a>
      <?php endwhile;
        else: ?>
          <p style="text-align:center;color:#777;">No hay productos intercambiados.</p>
      <?php endif;
        $stmt->close();
      ?>
    </div>
  </section>

  
  <?php if (isset($_SESSION['id_usuario']) && $_SESSION['id_usuario'] != $id_usuario): ?>
  <div class="centrar-boton">
    <button class="btn-reportar" onclick="abrirModalReporte()"> Reportar usuario</button>
  </div>

  <div id="modalReporte" class="modal-reporte">
    <div class="modal-contenido">
      <h3> Reportar usuario</h3>
      <p style="font-size: 0.9rem; color:#333;">Si detectaste comportamiento inapropiado o sospechoso, completá este formulario.</p>
      <form action="php/controller.php" method="POST">
        <input type="hidden" name="action" value="reportar_usuario">
        <input type="hidden" name="id_reportado" value="<?= $id_usuario ?>">
        
        <label for="motivo">Motivo del reporte:</label>
        <select name="motivo" required>
          <option value="">Seleccionar...</option>
          <option value="Comportamiento inapropiado">Comportamiento inapropiado</option>
          <option value="Estafa o fraude">Estafa o fraude</option>
          <option value="Spam o mensajes molestos">Spam o mensajes molestos</option>
          <option value="Otro">Otro</option>
        </select>

        <label for="descripcion">Descripción (opcional):</label>
        <textarea name="descripcion" rows="3" placeholder="Describe brevemente el motivo del reporte..."></textarea>

        <div class="botones-modal">
          <button type="button" class="btn-cancelar" onclick="cerrarModalReporte()">Cancelar</button>
          <button type="submit" class="btn-enviar">Enviar reporte</button>
        </div>
      </form>
    </div>
  </div>
  <?php endif; ?>
</main>

<script>
function abrirModalReporte() {
  document.getElementById('modalReporte').style.display = 'flex';
}
function cerrarModalReporte() {
  document.getElementById('modalReporte').style.display = 'none';
}
window.onclick = function(e) {
  const modal = document.getElementById('modalReporte');
  if (e.target === modal) modal.style.display = 'none';
}
</script>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>
<?php $mysqli->close(); ?>
</body>
</html>
