<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['id_usuario']) || strtolower($_SESSION['rol']) !== 'administrador') {
    header("Location: index.php");
    exit;
}

$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) die("Error DB: " . $mysqli->connect_error);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración - IntercambioYA</title>
  <link rel="stylesheet" href="css/admin_panel.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>

<header class="header">
  <h1> Panel de Administración</h1>
  <nav>
    <a href="intercambio.php">Volver al sitio</a>
    <form action="php/controller.php" method="POST" class="logout-form">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Cerrar sesión</button>
    </form>
  </nav>
</header>

<main>
  
  <section>
    <h2> Usuarios registrados</h2>
    <table>
      <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Acción</th></tr>
      <?php
      $usuarios = $mysqli->query("SELECT id_usuario, primer_nombre, email, rol FROM Usuario");
      while ($u = $usuarios->fetch_assoc()):
      ?>
        <tr>
          <td><?= $u['id_usuario'] ?></td>
          <td>
            <?php if (strtolower($u['rol']) !== 'administrador'): ?>
              <a href="perfil_usuario.php?id=<?= $u['id_usuario'] ?>" style="color:#0A66C2;font-weight:600;text-decoration:none;">
                <?= htmlspecialchars($u['primer_nombre']) ?>
              </a>
            <?php else: ?>
              <span style="color:gray;">Administrador</span>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= htmlspecialchars($u['rol']) ?></td>
          <td>
            <?php if (strtolower($u['rol']) !== 'administrador'): ?>
              <a class="btn eliminar" href="php/controller.php?action=eliminar_usuario&id=<?= $u['id_usuario'] ?>" onclick="return confirm('¿Eliminar este usuario?');">Eliminar</a>
            <?php else: ?>
              <span class="bloqueado">Bloqueado</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </section>

  
  <section>
    <h2> Reportes de usuarios</h2>
    <table>
      <tr><th>ID</th><th>Reportante</th><th>Reportado</th><th>Motivo</th><th>Descripción</th><th>Fecha</th><th>Acción</th></tr>
      <?php
      $reportes = $mysqli->query("
        SELECT R.id_reporte, U1.id_usuario AS id_reportante, U2.id_usuario AS id_reportado,
               U1.primer_nombre AS reportante, U2.primer_nombre AS reportado,
               R.motivo, R.descripcion, R.fecha_reporte 
        FROM Reporte R
        JOIN Usuario U1 ON R.id_reportante = U1.id_usuario
        JOIN Usuario U2 ON R.id_reportado = U2.id_usuario
        ORDER BY R.id_reporte DESC
      ");
      if ($reportes->num_rows > 0):
        while ($r = $reportes->fetch_assoc()): ?>
        <tr>
          <td><?= $r['id_reporte'] ?></td>
          <td>
            <a href="perfil_usuario.php?id=<?= $r['id_reportante'] ?>" style="color:#0A66C2;text-decoration:none;font-weight:600;">
              <?= htmlspecialchars($r['reportante']) ?>
            </a>
          </td>
          <td>
            <?php if (strtolower($r['reportado']) !== 'administrador'): ?>
              <a href="perfil_usuario.php?id=<?= $r['id_reportado'] ?>" style="color:#0A66C2;text-decoration:none;font-weight:600;">
                <?= htmlspecialchars($r['reportado']) ?>
              </a>
            <?php else: ?>
              <span style="color:gray;">Administrador</span>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($r['motivo']) ?></td>
          <td><?= htmlspecialchars($r['descripcion']) ?></td>
          <td><?= $r['fecha_reporte'] ?></td>
          <td><a class="btn eliminar" href="php/controller.php?action=eliminar_reporte&id=<?= $r['id_reporte'] ?>" onclick="return confirm('¿Eliminar este reporte?');">Borrar</a></td>
        </tr>
      <?php endwhile; else: ?>
        <tr><td colspan="7" style="text-align:center;">No hay reportes.</td></tr>
      <?php endif; ?>
    </table>
  </section>

  
  <section>
    <h2> Productos publicados</h2>
    <table>
      <tr><th>ID</th><th>Nombre</th><th>Usuario</th><th>Estado</th><th>Acción</th></tr>
      <?php
      $productos = $mysqli->query("
        SELECT P.id_producto, P.nombre, P.estado, U.id_usuario, U.primer_nombre, U.rol
        FROM Producto P
        JOIN Usuario U ON P.id_usuario = U.id_usuario
        ORDER BY P.id_producto DESC
      ");
      while ($p = $productos->fetch_assoc()):
      ?>
        <tr>
          <td><?= $p['id_producto'] ?></td>
          <td><?= htmlspecialchars($p['nombre']) ?></td>
          <td>
            <?php if (strtolower($p['rol']) !== 'administrador'): ?>
              <a href="perfil_usuario.php?id=<?= $p['id_usuario'] ?>" style="color:#0A66C2;text-decoration:none;font-weight:600;">
                <?= htmlspecialchars($p['primer_nombre']) ?>
              </a>
            <?php else: ?>
              <span style="color:gray;">Administrador</span>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($p['estado']) ?></td>
          <td><a class="btn eliminar" href="php/controller.php?action=eliminar_producto_admin&id=<?= $p['id_producto'] ?>" onclick="return confirm('¿Eliminar este producto?');">Eliminar</a></td>
        </tr>
      <?php endwhile; ?>
    </table>
  </section>

  
  <section>
    <h2> Chats activos</h2>
    <table>
      <tr><th>ID</th><th>Usuario 1</th><th>Usuario 2</th><th>Trueque</th><th>Acción</th></tr>
      <?php
      $chats = $mysqli->query("
        SELECT C.id_chat, C.id_trueque,
               U1.id_usuario AS id1, U1.primer_nombre AS usuario1, U1.rol AS rol1,
               U2.id_usuario AS id2, U2.primer_nombre AS usuario2, U2.rol AS rol2
        FROM Chat C
        JOIN Usuario U1 ON C.id_usuario1 = U1.id_usuario
        JOIN Usuario U2 ON C.id_usuario2 = U2.id_usuario
      ");
      if ($chats->num_rows > 0):
        while ($c = $chats->fetch_assoc()): ?>
        <tr>
          <td><?= $c['id_chat'] ?></td>
          <td>
            <?php if (strtolower($c['rol1']) !== 'administrador'): ?>
              <a href="perfil_usuario.php?id=<?= $c['id1'] ?>" style="color:#0A66C2;text-decoration:none;font-weight:600;">
                <?= htmlspecialchars($c['usuario1']) ?>
              </a>
            <?php else: ?>
              <span style="color:gray;">Administrador</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if (strtolower($c['rol2']) !== 'administrador'): ?>
              <a href="perfil_usuario.php?id=<?= $c['id2'] ?>" style="color:#0A66C2;text-decoration:none;font-weight:600;">
                <?= htmlspecialchars($c['usuario2']) ?>
              </a>
            <?php else: ?>
              <span style="color:gray;">Administrador</span>
            <?php endif; ?>
          </td>
          <td><?= $c['id_trueque'] ?></td>
          <td><a class="btn eliminar" href="php/controller.php?action=eliminar_chat&id=<?= $c['id_chat'] ?>" onclick="return confirm('¿Eliminar este chat?');">Eliminar</a></td>
        </tr>
      <?php endwhile; else: ?>
        <tr><td colspan="5" style="text-align:center;">No hay chats activos.</td></tr>
      <?php endif; ?>
    </table>
  </section>
</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Panel de Administración</p>
</footer>

</body>
</html>

<?php $mysqli->close(); ?>
