<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuario = $_SESSION['primer_nombre'] ?? null;
if (!$usuario) {
  header("Location: index.php");
  exit;
}

// Conexión a la base de datos
$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
  die("Error DB: " . $mysqli->connect_error);
}

// 🔹 Traer categorías desde la base de datos
$categorias = [];
$result = $mysqli->query("SELECT nombre FROM Categoria ORDER BY nombre ASC");
while ($row = $result->fetch_assoc()) {
  $categorias[] = $row['nombre'];
}
$result->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Subir Producto - IntercambioYA</title>
  <link rel="stylesheet" href="css/subir.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" class="logo" alt="IntercambioYA" />
    <a href="intercambio.php" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <a href="mis_trueques.php">Mis intercambios</a>
    <a href="chats.php" class="active">Chats</a>
    <a href="perfil.php">Mi perfil</a>
    <form action="php/controller.php" method="POST" style="display:inline;">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Cerrar sesión</button>
    </form>
  </nav>
</header>

<section class="formulario-subida">
  <h1>Subí tu producto</h1>
  <form action="php/controller.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="action" value="upload_product">

    <label for="imagen">Imagen</label>
    <input type="file" name="imagen" id="imagen" accept="image/*" required onchange="previewImage(event)">
    <img id="preview" style="display:none;margin-top:10px;max-width:200px;border-radius:10px;">

    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" placeholder="Ej: Bicicleta de paseo" required>

    <label for="descripcion">Descripción</label>
    <textarea name="descripcion" rows="4" placeholder="Detalles del producto, estado, etc." required></textarea>

    <label for="categoria">Categoría</label>
    <select name="categoria" required>
      <option value="">Seleccionar...</option>
      <?php if (empty($categorias)): ?>
        <option disabled>No hay categorías disponibles</option>
      <?php else: ?>
        <?php foreach ($categorias as $cat): ?>
          <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
        <?php endforeach; ?>
      <?php endif; ?>
    </select>

    <label for="condicion">Condición del producto</label>
    <select name="condicion" required>
      <option value="">Seleccionar...</option>
      <option value="Nuevo">Nuevo</option>
      <option value="Usado">Usado</option>
      <option value="Dañado">Dañado</option>
    </select>

    <button type="submit" class="btn-publicar">Publicar producto</button>
  </form>
</section>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

<script>
function previewImage(event) {
  const img = document.getElementById('preview');
  img.src = URL.createObjectURL(event.target.files[0]);
  img.style.display = 'block';
}
</script>

</body>
</html>
