<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$id_usuario = $_SESSION['id_usuario'];


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}


$sql_ofrecidos = "
SELECT 
  T.id_trueque, T.estado,
  P1.nombre AS producto_ofrecido,
  P2.nombre AS producto_objetivo,
  U.primer_nombre AS receptor
FROM Trueque T
JOIN Producto P1 ON T.id_producto_ofrecido = P1.id_producto
JOIN Producto P2 ON T.id_producto_objetivo = P2.id_producto
JOIN Usuario U ON T.id_usuario2 = U.id_usuario
WHERE T.id_usuario1 = ?
ORDER BY T.id_trueque DESC";
$stmt = $mysqli->prepare($sql_ofrecidos);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$ofrecidos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


$sql_recibidos = "
SELECT 
  T.id_trueque, T.estado,
  P1.nombre AS producto_ofrecido,
  P2.nombre AS producto_objetivo,
  U.primer_nombre AS oferente
FROM Trueque T
JOIN Producto P1 ON T.id_producto_ofrecido = P1.id_producto
JOIN Producto P2 ON T.id_producto_objetivo = P2.id_producto
JOIN Usuario U ON T.id_usuario1 = U.id_usuario
WHERE T.id_usuario2 = ?
ORDER BY T.id_trueque DESC";
$stmt = $mysqli->prepare($sql_recibidos);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$recibidos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


$sql_historial = "
SELECT 
  T.id_trueque, T.estado,
  P1.nombre AS producto_ofrecido,
  P2.nombre AS producto_objetivo,
  U1.primer_nombre AS usuario1,
  U2.primer_nombre AS usuario2
FROM Trueque T
JOIN Producto P1 ON T.id_producto_ofrecido = P1.id_producto
JOIN Producto P2 ON T.id_producto_objetivo = P2.id_producto
JOIN Usuario U1 ON T.id_usuario1 = U1.id_usuario
JOIN Usuario U2 ON T.id_usuario2 = U2.id_usuario
WHERE (T.id_usuario1 = ? OR T.id_usuario2 = ?)
  AND T.estado IN ('Finalizado', 'Rechazado', 'Cancelado')
ORDER BY T.id_trueque DESC";

$stmt = $mysqli->prepare($sql_historial);
$stmt->bind_param("ii", $id_usuario, $id_usuario);
$stmt->execute();
$historial = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Mis Intercambios - IntercambioYA</title>
<link rel="stylesheet" href="css/trueques.css" />
<link rel="stylesheet" href="css/style.css" />
<link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">
</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" class="logo" alt="Logo IntercambioYA" />
    <a href="<?= htmlspecialchars($_SESSION['pagina_origen'] ?? 'intercambio.php') ?>" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <a href="perfil.php">Mi perfil</a>
    <form action="php/controller.php" method="POST" class="logout-form">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Cerrar sesión</button>
    </form>
  </nav>
</header>

<main class="trueques-container">

  
  <section class="trueques-section">
    <h2>Intercambios Ofrecidos</h2>
    <?php if (empty($ofrecidos)): ?>
      <p class="vacio">No ofreciste ningún Intercambio todavía.</p>
    <?php else: ?>
      <div class="lista-trueques">
        <?php foreach ($ofrecidos as $t): if ($t['estado'] === 'Pendiente'): ?>
          <div class="trueque-card">
            
            <a href="php/eliminar_trueque.php?id=<?= $t['id_trueque'] ?>" class="btn-eliminar-x" title="Eliminar trueque" onclick="return confirm('¿Seguro que deseas eliminar este trueque?');">×</a>

            <p><strong>Producto ofrecido:</strong> <?= htmlspecialchars($t['producto_ofrecido']) ?></p>
            <p><strong>Para:</strong> <?= htmlspecialchars($t['receptor']) ?></p>
            <p><strong>Producto deseado:</strong> <?= htmlspecialchars($t['producto_objetivo']) ?></p>
            <p><strong>Estado:</strong> <?= htmlspecialchars($t['estado']) ?></p>
          </div>
        <?php endif; endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  
  <section class="trueques-section">
    <h2>Intercambios Recibidos</h2>
    <?php if (empty($recibidos)): ?>
      <p class="vacio">Todavía no recibiste propuestas de intercambio.</p>
    <?php else: ?>
      <div class="lista-trueques">
        <?php foreach ($recibidos as $t): if ($t['estado'] === 'Pendiente'): ?>
          <div class="trueque-card">
            <a href="php/eliminar_trueque.php?id=<?= $t['id_trueque'] ?>" class="btn-eliminar-x" title="Eliminar trueque" onclick="return confirm('¿Seguro que deseas eliminar este trueque?');">×</a>

            <p><strong>De:</strong> <?= htmlspecialchars($t['oferente']) ?></p>
            <p><strong>Te ofrece:</strong> <?= htmlspecialchars($t['producto_ofrecido']) ?></p>
            <p><strong>Por tu:</strong> <?= htmlspecialchars($t['producto_objetivo']) ?></p>
            <p><strong>Estado:</strong> <?= htmlspecialchars($t['estado']) ?></p>

            <div class="acciones-trueque">
              <a href="php/gestionar_trueque.php?id=<?= $t['id_trueque'] ?>&accion=aceptar" class="btn-aceptar">Aceptar</a>
              <a href="php/gestionar_trueque.php?id=<?= $t['id_trueque'] ?>&accion=rechazar" class="btn-rechazar">Rechazar</a>
            </div>
          </div>
        <?php endif; endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  
  <section class="trueques-section">
    <h2>Historial</h2>
    <?php if (empty($historial)): ?>
      <p class="vacio">No hay trueques finalizados ni cancelados.</p>
    <?php else: ?>
      <div class="lista-trueques">
        <?php foreach ($historial as $h): ?>
          <div class="trueque-card historial">
            <p><strong>Entre:</strong> <?= htmlspecialchars($h['usuario1']) ?> y <?= htmlspecialchars($h['usuario2']) ?></p>
            <p><strong>Producto ofrecido:</strong> <?= htmlspecialchars($h['producto_ofrecido']) ?></p>
            <p><strong>Por:</strong> <?= htmlspecialchars($h['producto_objetivo']) ?></p>
            <p><strong>Estado:</strong> <?= htmlspecialchars($h['estado']) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

</body>
</html>

<?php $mysqli->close(); ?>
