<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$id_usuario = $_SESSION['id_usuario'] ?? null;
$rol = $_SESSION['rol'] ?? '';

if (!$id_usuario) {
    header("Location: index.php");
    exit;
}


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}


if (isset($_GET['ocultar']) && is_numeric($_GET['ocultar'])) {
    $id_chat = (int)$_GET['ocultar'];

    
    $sel = $mysqli->prepare("SELECT id_usuario1, id_usuario2 FROM Chat WHERE id_chat = ?");
    $sel->bind_param("i", $id_chat);
    $sel->execute();
    $chat = $sel->get_result()->fetch_assoc();
    $sel->close();

    if ($chat) {
        if ($chat['id_usuario1'] == $id_usuario) {
            $update = $mysqli->prepare("UPDATE Chat SET oculto_usuario1 = '1' WHERE id_chat = ?");
        } elseif ($chat['id_usuario2'] == $id_usuario) {
            $update = $mysqli->prepare("UPDATE Chat SET oculto_usuario2 = '1' WHERE id_chat = ?");
        }

        if (isset($update)) {
            $update->bind_param("i", $id_chat);
            $update->execute();
            $update->close();
        }
    }

    header("Location: chats.php");
    exit;
}


if (strcasecmp($rol, 'Administrador') === 0) {
    
    $query = "
        SELECT 
            c.id_chat, 
            c.fecha_inicio, 
            t.estado AS estado_trueque,
            u1.id_usuario AS id1,
            u2.id_usuario AS id2,
            CONCAT(u1.primer_nombre, ' y ', u2.primer_nombre) AS otro_nombre,
            '' AS otro_foto
        FROM Chat c
        JOIN Usuario u1 ON c.id_usuario1 = u1.id_usuario
        JOIN Usuario u2 ON c.id_usuario2 = u2.id_usuario
        JOIN Trueque t ON c.id_trueque = t.id_trueque
        ORDER BY c.fecha_inicio DESC
    ";
    $chats = $mysqli->query($query)->fetch_all(MYSQLI_ASSOC);
} else {
    
    $stmt = $mysqli->prepare("
        SELECT 
            c.id_chat, 
            c.fecha_inicio, 
            t.estado AS estado_trueque,
            u1.id_usuario AS id1,
            u2.id_usuario AS id2,
            IF(c.id_usuario1 = ?, u2.primer_nombre, u1.primer_nombre) AS otro_nombre,
            IF(c.id_usuario1 = ?, u2.foto_perfil, u1.foto_perfil) AS otro_foto,
            c.oculto_usuario1,
            c.oculto_usuario2
        FROM Chat c
        JOIN Usuario u1 ON c.id_usuario1 = u1.id_usuario
        JOIN Usuario u2 ON c.id_usuario2 = u2.id_usuario
        JOIN Trueque t ON c.id_trueque = t.id_trueque
        WHERE 
          ((c.id_usuario1 = ? AND c.oculto_usuario1 = '0')
           OR (c.id_usuario2 = ? AND c.oculto_usuario2 = '0'))
        ORDER BY c.fecha_inicio DESC
    ");
    $stmt->bind_param("iiii", $id_usuario, $id_usuario, $id_usuario, $id_usuario);
    $stmt->execute();
    $chats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mis Chats - IntercambioYA</title>
  <link rel="stylesheet" href="css/chat.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo">
    <a href="intercambio.php" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <?php if (strcasecmp($rol, 'Administrador') === 0): ?>
      <a href="admin_panel.php"> Panel de administración</a>
      <a href="intercambio.php"> Productos</a>
      <form action="php/controller.php" method="POST" class="logout-form">
        <input type="hidden" name="action" value="logout">
        <button type="submit">Cerrar sesión</button>
      </form>
    <?php else: ?>
      <a href="intercambio.php">Intercambios</a>
      <a href="perfil.php">Mi perfil</a>
      <form action="php/controller.php" method="POST" class="logout-form">
        <input type="hidden" name="action" value="logout">
        <button type="submit">Cerrar sesión</button>
      </form>
    <?php endif; ?>
  </nav>
</header>

<main class="chats-list">
  <h1><?= (strcasecmp($rol, 'Administrador') === 0) ? ' Chats (modo vigilancia)' : 'Mis Chats' ?></h1>

  <?php if (empty($chats)): ?>
    <p style="text-align:center;color:#555;">No hay chats visibles actualmente.</p>
  <?php else: ?>
    <?php foreach ($chats as $c): 
        $foto_otro = !empty($c['otro_foto']) ? $c['otro_foto'] : 'img/default-user.png';
        $estado = $c['estado_trueque'];
    ?>
      <div class="chat-item">
        <div style="display:flex;align-items:center;gap:10px;">
          <img src="<?= htmlspecialchars($foto_otro) ?>" 
               alt="foto" 
               style="width:50px;height:50px;border-radius:50%;object-fit:cover;">
          <div>
            <p><strong><?= htmlspecialchars($c['otro_nombre']) ?></strong></p>
            <small><?= date("d/m/Y H:i", strtotime($c['fecha_inicio'])) ?></small>
          </div>
        </div>

        <div class="chat-actions">
          <span class="chat-estado">
            <?php 
              if ($estado === 'Finalizado') echo "Finalizado";
              elseif ($estado === 'Cancelado') echo "Cancelado";
              else echo "En curso";
            ?>
          </span>

          <a href="chat.php?id_chat=<?= $c['id_chat'] ?>" class="btn-intercambio">
            <?= (strcasecmp($rol, 'Administrador') === 0) ? 'Ver chat' : 'Ir al chat' ?>
          </a>

          <?php if (strcasecmp($rol, 'Administrador') !== 0): ?>
            <a href="chats.php?ocultar=<?= $c['id_chat'] ?>" 
               onclick="return confirm('¿Seguro que querés eliminar este chat de tu vista?');" 
               class="btn-eliminar">Eliminar</a>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

</body>
</html>

<?php $mysqli->close(); ?>
