<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuario = $_SESSION['primer_nombre'] ?? null;
$rol = $_SESSION['rol'] ?? null;
$id = (int)($_GET['id'] ?? 0);


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("DB error: " . $mysqli->connect_error);
}


$stmt = $mysqli->prepare("
    SELECT 
        p.id_producto, p.nombre, p.descripcion, p.estado, p.condicion, p.foto, p.id_usuario,
        u.primer_nombre, c.nombre AS categoria
    FROM Producto p
    LEFT JOIN Usuario u ON p.id_usuario = u.id_usuario
    LEFT JOIN Categoria c ON p.id_categoria = c.id_categoria
    WHERE p.id_producto = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$producto = $res->fetch_assoc();
$stmt->close();

if (!$producto) {
    echo "<h2 style='text-align:center;color:red;margin-top:3rem;'>Producto no encontrado.</h2>";
    exit;
}

$id_usuario_sesion = $_SESSION['id_usuario'] ?? 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($producto['nombre']) ?> - Detalle del producto</title>
  <link rel="stylesheet" href="css/detalle.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/responsive.css" />
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>


<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" class="logo" alt="IntercambioYA">
    <a href="<?= htmlspecialchars($_SESSION['pagina_origen'] ?? 'intercambio.php') ?>" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <?php if ($id_usuario_sesion): ?>
      <?php if (strcasecmp($rol ?? '', 'Administrador') === 0): ?>
        
        <a href="admin_panel.php">Panel de administración</a>
        <a href="intercambio.php">Productos</a>
        <a href="chats.php">Vigilar Chats</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php else: ?>
        
        <a href="index.php">Inicio</a>
        <a href="intercambio.php">Intercambios</a>
        <a href="mis_trueques.php">Mis Intercambios</a>
        <a href="chats.php">Chats</a>
        <a href="perfil.php">Mi perfil</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php endif; ?>
    <?php else: ?>
      
      <a href="index.php">Inicio</a>
      <a href="#" onclick="abrirModal('modalRegistro')">Registro</a>
      <a href="#" onclick="abrirModal('modalLogin')">Iniciar sesión</a>
    <?php endif; ?>
  </nav>
</header>


<main class="product-detail">
  <div class="images-section">
    <img src="<?= htmlspecialchars($producto['foto'] ?: 'img/default-product.png') ?>" 
         alt="<?= htmlspecialchars($producto['nombre']) ?>" 
         class="main-image">
  </div>

  <div class="info-section">
    <h1><?= htmlspecialchars($producto['nombre']) ?></h1>
    <p><strong>Publicado por:</strong> 
      <a href="perfil_usuario.php?id=<?= (int)$producto['id_usuario'] ?>" class="link-autor">
        <?= htmlspecialchars($producto['primer_nombre']) ?>
      </a>
    </p>
    <?php if (!empty($producto['categoria'])): ?>
      <p><strong>Categoría:</strong> <?= htmlspecialchars($producto['categoria']) ?></p>
    <?php endif; ?>
    <p><strong>Estado:</strong> 
      <span style="color: <?= $producto['estado'] === 'Intercambiado' ? 'red' : 'green' ?>;">
        <?= htmlspecialchars($producto['estado']) ?>
      </span>
    </p>
    <p><strong>Condición:</strong> <?= htmlspecialchars($producto['condicion'] ?: 'Sin especificar') ?></p>
    <p><strong>Descripción:</strong> <?= nl2br(htmlspecialchars($producto['descripcion'])) ?></p>

    
    <?php if (strcasecmp($rol ?? '', 'Administrador') === 0): ?>
      <div class="alerta" style="background-color:#e7f3fe;color:#0A66C2;padding:10px;border-radius:8px;">
         Modo administrador — solo vista informativa. No se pueden realizar trueques.
      </div>

    <?php elseif ($producto['estado'] === 'Intercambiado'): ?>
      <div class="alerta" style="background-color:#ffdddd;color:#a00;padding:10px;border-radius:8px;">
        Este producto ya fue intercambiado y no se puede ofrecer un nuevo trueque.
      </div>

    <?php elseif ($id_usuario_sesion == $producto['id_usuario']): ?>
      <div class="alerta" style="background-color:#fff3cd;color:#856404;padding:10px;border-radius:8px;">
        Este producto es tuyo. No podés ofrecer un trueque contigo mismo.
      </div>

    <?php elseif ($id_usuario_sesion): ?>
      <form action="seleccionar_producto.php" method="POST">
        <input type="hidden" name="id_producto_destino" value="<?= (int)$producto['id_producto'] ?>">
        <button type="submit" class="btn-trueque">Ofrecer trueque</button>
      </form>

    <?php else: ?>
      <div class="alerta" style="background-color:#e7f3fe;color:#31708f;padding:10px;border-radius:8px;">
        Iniciá sesión para ofrecer un trueque.
      </div>
    <?php endif; ?>
  </div>
</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>
</body>
</html>

<?php $mysqli->close(); ?>
