<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$id_usuario = $_SESSION['id_usuario'] ?? null;
$rol = $_SESSION['rol'] ?? '';

if (!$id_usuario) {
    header("Location: index.php");
    exit;
}

$id_chat = (int)($_GET['id_chat'] ?? 0);


$mysqli = new mysqli("localhost", "root", "root", "IntercambioYA");
if ($mysqli->connect_errno) {
    die("DB error: " . $mysqli->connect_error);
}


if (strcasecmp($rol, 'Administrador') !== 0 && $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['contenido'])) {
    $contenido = trim($_POST['contenido']);
    if ($contenido !== '' && $id_chat > 0) {
        $stmt = $mysqli->prepare("
            INSERT INTO Mensaje (id_chat, id_usuario, contenido, fecha_envio)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param("iis", $id_chat, $id_usuario, $contenido);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: chat.php?id_chat=" . $id_chat);
    exit;
}


$stmt = $mysqli->prepare("
    SELECT 
        c.id_chat,
        c.id_trueque,
        c.id_usuario1,
        c.id_usuario2,
        u1.primer_nombre AS nombre1,
        u1.foto_perfil AS foto1,
        u2.primer_nombre AS nombre2,
        u2.foto_perfil AS foto2,
        t.estado AS estado_trueque,
        t.confirmaciones
    FROM Chat c
    JOIN Usuario u1 ON c.id_usuario1 = u1.id_usuario
    JOIN Usuario u2 ON c.id_usuario2 = u2.id_usuario
    LEFT JOIN Trueque t ON c.id_trueque = t.id_trueque
    WHERE c.id_chat = ?
    LIMIT 1
");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$chat = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$chat) {
    die("<h2 style='text-align:center;margin-top:3rem;color:#0A66C2;'> Chat no encontrado.</h2>");
}


if (strcasecmp($rol, 'Administrador') !== 0 &&
    $id_usuario != $chat['id_usuario1'] &&
    $id_usuario != $chat['id_usuario2']) {
    die("<h2 style='text-align:center;margin-top:3rem;color:#dc3545;'> No tenés permiso para ver este chat.</h2>");
}

$estadoTrueque = $chat['estado_trueque'] ?? 'Desconocido';
$confirmaciones = $chat['confirmaciones'] ?? 0;


if ($id_usuario == $chat['id_usuario1']) {
    $nombre_otro = $chat['nombre2'];
    $foto_otro = $chat['foto2'];
} else {
    $nombre_otro = $chat['nombre1'];
    $foto_otro = $chat['foto1'];
}


$stmt = $mysqli->prepare("
    SELECT id_mensaje, contenido, fecha_envio, id_usuario
    FROM Mensaje
    WHERE id_chat = ?
    ORDER BY fecha_envio ASC
");
$stmt->bind_param("i", $id_chat);
$stmt->execute();
$mensajes = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


$stmt = $mysqli->prepare("SELECT foto_perfil FROM Usuario WHERE id_usuario = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$yo = $stmt->get_result()->fetch_assoc();
$stmt->close();

$miFoto = $yo['foto_perfil'] ?? 'img/default-user.png';
$fotoOtro = $foto_otro ?? 'img/default-user.png';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Chat con <?= htmlspecialchars($nombre_otro) ?> - IntercambioYA</title>
<link rel="stylesheet" href="css/chat.css">
</head>
<body>
<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo">
    <a href="chats.php" class="volver">← Volver</a>
  </div>
  <nav class="nav-links">
    <?php if (strcasecmp($rol, 'Administrador') === 0): ?>
      <a href="admin_panel.php"> Panel</a>
      <a href="intercambio.php"> Productos</a>
      <form action="php/controller.php" method="POST" class="logout-form">
        <input type="hidden" name="action" value="logout">
        <button type="submit">Cerrar sesión</button>
      </form>
    <?php else: ?>
  <a href="intercambio.php">Intercambios</a>
  <a href="perfil.php">Mi perfil</a>
  <form action="php/controller.php" method="POST" class="logout-form" style="display:inline;">
    <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">
    <input type="hidden" name="action" value="logout">
    <button type="submit" class="logout-btn">Cerrar sesión</button>
  </form>
<?php endif; ?>

  </nav>
</header>

<main class="chat-container">

  
  <?php if (strcasecmp($rol, 'Administrador') === 0): ?>
    <div style="text-align:center;background:#0A66C2;color:white;padding:10px;border-radius:6px;margin-bottom:1rem;">
       Modo vigilancia activo — estás viendo una conversación entre 
      <b><?= htmlspecialchars($chat['nombre1']) ?></b> y 
      <b><?= htmlspecialchars($chat['nombre2']) ?></b>
    </div>
  <?php endif; ?>

  
  <?php if ($estadoTrueque === 'Finalizado'): ?>
    <p style="text-align:center;color:green;font-weight:bold;">Este trueque fue completado exitosamente.</p>
  <?php elseif ($estadoTrueque === 'Cancelado'): ?>
    <p style="text-align:center;color:red;font-weight:bold;">Este trueque fue cancelado, pero el chat sigue disponible.</p>
  <?php else: ?>
    <p style="text-align:center;color:#0A66C2;font-weight:bold;">Confirmaciones: <?= $confirmaciones ?>/2</p>
  <?php endif; ?>

  
  <div class="mensajes" id="mensajes">
    <?php if (empty($mensajes)): ?>
      <p style="text-align:center;color:#777;">No hay mensajes todavía.</p>
    <?php else: ?>
      <?php foreach ($mensajes as $m): ?>
        <?php $esYo = $m['id_usuario'] == $id_usuario; ?>
        <div class="msg <?= $esYo ? 'yo' : 'otro' ?>">
          <img src="<?= htmlspecialchars($esYo ? $miFoto : $fotoOtro) ?>" class="avatar-chat">
          <div>
            <div class="contenido"><?= nl2br(htmlspecialchars($m['contenido'])) ?></div>
            <div class="hora"><?= date("H:i", strtotime($m['fecha_envio'])) ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  
  <?php if (strcasecmp($rol, 'Administrador') !== 0): ?>
    <form method="POST" action="chat.php?id_chat=<?= $id_chat ?>">
      <input type="text" name="contenido" placeholder="Escribí un mensaje..." required autocomplete="off">
      <button type="submit">Enviar</button>
    </form>
  <?php else: ?>
    <div style="text-align:center;color:#777;font-style:italic;margin-top:1rem;">
       Solo lectura (modo administrador)
    </div>
  <?php endif; ?>

 
  <?php if (strcasecmp($rol, 'Administrador') !== 0 && in_array($estadoTrueque, ['Pendiente', 'Aceptado'])): ?>
    <div class="acciones-trueque">
      <a href="php/finalizar_trueque.php?id=<?= $chat['id_trueque'] ?>&accion=confirmar" class="btn-confirmar">Confirmar</a>
      <a href="php/finalizar_trueque.php?id=<?= $chat['id_trueque'] ?>&accion=cancelar" class="btn-cancelar" onclick="return confirm('¿Seguro que querés cancelar el trueque?');">Cancelar</a>
    </div>
  <?php endif; ?>
</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

<script>
const cont = document.getElementById("mensajes");
if (cont) cont.scrollTop = cont.scrollHeight;
</script>
</body>
</html>

<?php $mysqli->close(); ?>
