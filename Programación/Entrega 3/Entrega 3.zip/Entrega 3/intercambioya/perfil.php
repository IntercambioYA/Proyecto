<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['id_usuario'])) {
  header("Location: index.php");
  exit;
}

$id_usuario = $_SESSION['id_usuario'];
$nombre = $_SESSION['primer_nombre'];

$mysqli = new mysqli("localhost","root","root","IntercambioYA");
if ($mysqli->connect_errno) die("DB error: ".$mysqli->connect_error);


$fotoRes = $mysqli->prepare("SELECT foto_perfil FROM Usuario WHERE id_usuario = ?");
$fotoRes->bind_param("i", $id_usuario);
$fotoRes->execute();
$foto = $fotoRes->get_result()->fetch_assoc()['foto_perfil'] ?? 'img/default-user.png';
$fotoRes->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Mi perfil - IntercambioYA</title>
  <link rel="stylesheet" href="css/perfil.css" />
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>
<body>

<header class="header">
  <div class="header-left">
    <img src="img/logo-intercambioya.png" class="logo" alt="Logo IntercambioYA" />
    <a href="<?= htmlspecialchars($_SESSION['pagina_origen'] ?? 'intercambio.php') ?>" class="volver">← Volver</a>
  </div>

  <nav class="nav-links">
    <a href="mis_trueques.php">Mis Intercambios</a>
    <a href="chats.php" class="active">Chats</a>
    <form action="php/controller.php" method="POST" style="display:inline;">
      <input type="hidden" name="action" value="logout">
      <button type="submit" class="logout-btn">Cerrar sesión</button>
    </form>
  </nav>
</header>

<main class="perfil-contenedor">
  <div class="perfil-box">
    <img id="fotoPerfil" src="<?= htmlspecialchars($foto) ?>" alt="Foto de perfil" class="foto-perfil">

    
    <button type="button" class="btn-intercambio" onclick="abrirModal('modalEditar')">
      Editar perfil
    </button>

    <h1><?= htmlspecialchars($nombre) ?></h1>
    <p class="correo"><?= htmlspecialchars($_SESSION['email']) ?></p>
  </div>

  
  <div id="modalEditar" class="modal">
    <div class="modal-contenido">
      <span class="cerrar" onclick="cerrarModal('modalEditar')">&times;</span>
      <h2>Editar perfil</h2>

      <form action="php/controller.php" method="POST" enctype="multipart/form-data" class="form-editar">
        <input type="hidden" name="action" value="editar_perfil">


        <label>Nombre:</label>
        <input type="text" name="primer_nombre" value="<?= htmlspecialchars($_SESSION['primer_nombre']) ?>" required>

        <label>Apellido:</label>
        <input type="text" name="apellido" value="<?= htmlspecialchars($_SESSION['apellido'] ?? '') ?>">

        <label>Correo:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($_SESSION['email']) ?>" required>

        <label>Nueva contraseña (opcional):</label>
        <input type="password" name="password" placeholder="Dejar en blanco para no cambiarla">

        <label>Foto de perfil:</label>
        <input type="file" name="foto_perfil" accept="image/*">

        <button type="submit" class="btn-guardar">Guardar cambios</button>
      </form>
    </div>
  </div>

  
  <section class="mis-productos">
    <h2>Productos Disponibles</h2>
    <div class="productos-grid">
      <?php
        $stmt = $mysqli->prepare("
          SELECT id_producto, nombre, foto 
          FROM Producto 
          WHERE id_usuario = ? AND estado = 'Disponible'
          ORDER BY id_producto DESC
        ");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0):
          while ($p = $res->fetch_assoc()): ?>
            <div class="producto-card">
              <img src="<?= htmlspecialchars($p['foto'] ?: 'img/default-product.png') ?>" alt="Producto">
              <p><strong><?= htmlspecialchars($p['nombre']) ?></strong></p>
              <a href="detalle.php?id=<?= $p['id_producto'] ?>" class="btn-ver">Ver</a>
              <form action="php/controller.php" method="POST" style="display:inline;">
                <input type="hidden" name="action" value="eliminar_producto">
                <input type="hidden" name="id_producto" value="<?= $p['id_producto'] ?>">
                <button type="submit" class="btn-eliminar" onclick="return confirm('¿Eliminar este producto?')">Eliminar</button>
              </form>
            </div>
      <?php endwhile;
        else: ?>
          <p style="text-align:center;color:#777;">No tenés productos disponibles.</p>
      <?php endif;
        $stmt->close();
      ?>
    </div>
  </section>

  
  <section class="mis-productos">
    <h2>Productos Intercambiados</h2>
    <div class="productos-grid">
      <?php
        $stmt = $mysqli->prepare("
          SELECT id_producto, nombre, foto 
          FROM Producto 
          WHERE id_usuario = ? AND estado = 'Intercambiado'
          ORDER BY id_producto DESC
        ");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0):
          while ($p = $res->fetch_assoc()): ?>
            <a href="detalle.php?id=<?= $p['id_producto'] ?>" class="producto-card intercambiado">
              <div class="overlay">
                <span>Intercambiado</span>
              </div>
              <img src="<?= htmlspecialchars($p['foto'] ?: 'img/default-product.png') ?>" alt="Producto intercambiado">
              <p><strong><?= htmlspecialchars($p['nombre']) ?></strong></p>
            </a>
      <?php endwhile;
        else: ?>
          <p style="text-align:center;color:#777;">No tenés productos intercambiados.</p>
      <?php endif;
        $stmt->close();
      ?>
    </div>
  </section>

</main>

<footer class="footer">
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>

<script>
function abrirModal(id){ document.getElementById(id).style.display='block'; }
function cerrarModal(id){ document.getElementById(id).style.display='none'; }
window.onclick=function(e){
  const modal=document.getElementById('modalEditar');
  if(e.target===modal){ modal.style.display='none'; }
}
</script>

</body>
</html>
<?php $mysqli->close(); ?>
