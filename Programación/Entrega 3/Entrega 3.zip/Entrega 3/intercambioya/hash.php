<?php
$hash = password_hash("Proyecto2025rngs", PASSWORD_DEFAULT);
echo $hash;
?>