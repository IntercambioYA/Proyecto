<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$usuario = $_SESSION['primer_nombre'] ?? null;
$rol = $_SESSION['rol'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IntercambioYA</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="icon" type="image/x-icon" href="favicon_intercambioya.ico">

</head>

<body>


<header class="header">
  <img src="img/logo-intercambioya.png" alt="Logo IntercambioYA" class="logo">

  <nav class="nav-links">
    <?php if (isset($_SESSION['id_usuario'])): ?>
      
      <?php if (strcasecmp($rol, 'Administrador') === 0): ?>
        
        <a href="admin_panel.php">Panel de Administración</a>
        <a href="intercambio.php">Productos</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>

      <?php else: ?>
        
        <a href="index.php">Inicio</a>
        <a href="#contacto">Contacto</a>
        <a href="perfil.php">Mi perfil</a>
        <form action="php/controller.php" method="POST" style="display:inline;">
          <input type="hidden" name="action" value="logout">
          <button type="submit" class="logout-btn">Cerrar sesión</button>
        </form>
      <?php endif; ?>

    <?php else: ?>
      
      <a href="#" onclick="abrirModal('modalRegistro')">Registro</a>
      <a href="#" onclick="abrirModal('modalLogin')">Iniciar sesión</a>
    <?php endif; ?>
  </nav>
</header>



<section id="bienvenida" class="welcome-section">
  <h1 class="bienvenida-titulo">Bienvenido a IntercambioYA</h1>
  <p>Intercambiá productos y servicios de manera sostenible.</p>
  <a href="intercambio.php"><button class="btn-intercambio">Ver Intercambios</button></a>
</section>

<section id="video-presentacion" style="
    padding: 2rem 0;
    background: #f5f5f5;
    text-align: center;
">
    
    <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 20px;
        margin-bottom: 1rem;
    ">
        <h2 style="
            color:#0A66C2;
            text-transform: uppercase;
            font-size: 1.8rem;
            margin: 0;
            font-weight: 700;
        ">
            IntercambioYA — Cómo usarlo
        </h2>

        <button onclick="cambiarIdioma()" style="
            background:#0A66C2;
            color:white;
            border:none;
            padding:0.6rem 1.2rem;
            border-radius:8px;
            cursor:pointer;
            font-size:0.9rem;
            font-weight:600;
        ">
            Cambiar idioma
        </button>
    </div>

    <video id="videoDemo" controls autoplay muted loop
           style="
               width:85%;
               max-width:900px;
               border-radius: 12px;
               border: 3px solid #0A66C2;
               box-shadow: 0 0 12px rgba(0,0,0,0.2);
           ">
        <source src="videos/presentacion.mp4" type="video/mp4">
        Tu navegador no soporta videos HTML5.
    </video>
</section>

<script>
let idioma = "ES";
function cambiarIdioma() {
    const video = document.getElementById("videoDemo");
    if (idioma === "ES") {
        idioma = "EN";
        video.src = "videos/presentacion_en.mp4";
    } else {
        idioma = "ES";
        video.src = "videos/presentacion.mp4";
    }
    video.play();
}
</script>




<footer class="footer" id="contacto">
  <h2>Contacto</h2>
  <ul class="contact-icons">
    <li><i class="fas fa-envelope"></i> rngs.company@gmail.com</li>
    <li><i class="fab fa-instagram"></i> @rngs_uy</li>
    <li><i class="fas fa-phone"></i> +598 097 424 949</li>
  </ul>
  <p>© 2025 IntercambioYA - Todos los derechos reservados</p>
</footer>


<div id="modalLogin" class="modal">
  <div class="modal-content">
    <span class="close" onclick="cerrarModal('modalLogin')">&times;</span>
    <h2>Iniciar Sesión</h2>
    <form action="php/controller.php" method="POST">
      <input type="hidden" name="action" value="login">
      <input type="email" name="email" placeholder="Correo electrónico" required autocomplete="off">
      <input type="password" name="clave" placeholder="Contraseña" required autocomplete="off">
      <button type="submit" class="btn-intercambio">Ingresar</button>
    </form>
  </div>
</div>

<div id="modalRegistro" class="modal">
  <div class="modal-content">
    <span class="close" onclick="cerrarModal('modalRegistro')">&times;</span>
    <h2>Registro</h2>
    <form action="php/controller.php" method="POST">
      <input type="hidden" name="action" value="register">
      <input type="text" name="primer_nombre" placeholder="Nombre" required autocomplete="off">
      <input type="text" name="primer_apellido" placeholder="Apellido" required autocomplete="off">
      <input type="email" name="email" placeholder="Correo electrónico" required autocomplete="off">
      <input type="tel" name="telefono" placeholder="Teléfono" autocomplete="off">
      <input type="password" name="clave" placeholder="Contraseña" required autocomplete="off">
      <button type="submit" class="btn-intercambio">Registrarse</button>
    </form>
  </div>
</div>


<script>
  function abrirModal(id){document.getElementById(id).style.display='block';}
  function cerrarModal(id){document.getElementById(id).style.display='none';}
  window.onclick=function(e){
    ['modalLogin','modalRegistro'].forEach(id=>{
      const m=document.getElementById(id);
      if(e.target===m)m.style.display="none";
    });
  };
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
